# Python-ML-model-Project
First ML model Project based on sklearn and using csv file from Kaggle on World Happiness report

This is the first ML project created by me and rehan. 
After many attempts on the regression model, we were able to set a score of 74 out of 100.
Test data was collected as 10%.
